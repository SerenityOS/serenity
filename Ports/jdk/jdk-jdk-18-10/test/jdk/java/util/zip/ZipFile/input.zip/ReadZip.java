/* @test %I% %E%
   @bug 4241361
   @summary Make sure we can read a zip file.
 */

import java.io.*;
import java.util.zip.*;

public class ReadZip {
    public static void main(String args[]) throws Exception {
        ZipFile zf = new ZipFile(new File(System.getProperty("test.src", "."), 
                                          "input.zip"));
        ZipEntry ze = zf.getEntry("ReadZip.java");
        if (ze == null) {
            throw new Exception("cannot read from zip file");
        }
    }
}
